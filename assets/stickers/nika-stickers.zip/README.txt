Nika Net sticker pack — 512x512 WEBP (Telegram-ready via @Stickers bot) + PNG.
MIT — nikanet.dpdns.org